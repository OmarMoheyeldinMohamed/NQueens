#include <iostream>
using namespace std;
bool solve(int n, int row);
