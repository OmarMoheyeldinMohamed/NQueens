#include <iostream>
using namespace std;
extern int grid[10][10];
void print(int);
