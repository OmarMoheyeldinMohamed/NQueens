#include<iostream>
using namespace std;
bool isSafe(int, int, int);

